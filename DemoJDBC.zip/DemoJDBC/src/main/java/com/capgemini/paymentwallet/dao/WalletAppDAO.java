package com.capgemini.paymentwallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.bean.AccountDetails;
import com.capgemini.paymentwallet.util.DBUtil;

public class WalletAppDAO implements IWalletAppDAO{

	static AccountDetails acc;
	static ResultSet rs;
	static String aadharNo;
	Connection con;

	public boolean loginAccount(String uName, String uPassword) {
		
		try {
			try {
				con = DBUtil.getConnection();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}

			String loginQuery = "select * from customerDetails WHERE username='" + uName + "' and password='" + uPassword + "'";
			PreparedStatement pstmt = con.prepareStatement(loginQuery);
			System.out.println(loginQuery);
			ResultSet rs = pstmt.executeQuery(loginQuery);
			while (rs.first()) {
				/*
				 * String s = "select * from account WHERE AadharNo='" + rs.getString(1) + "'";
				 * PreparedStatement pstmt1 = con.prepareStatement(s); rs1 =
				 * pstmt1.executeQuery();
				 * 
				 */
				aadharNo = rs.getString("aadharNo");
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	
	public boolean addWalletDetails(AccountDetails wallet) {
		
		int n = 0;
		int n1 = 0;
		
		try {

			try {
				con = DBUtil.getConnection();
			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
			
		
			String updateQuery = "Insert into customerDetails values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(updateQuery);

			pstmt.setString(1, wallet.getCustomerDetails().getAadharNo());
			pstmt.setString(2, wallet.getCustomerDetails().getCustName());
			pstmt.setInt(3, wallet.getCustomerDetails().getAge());
			pstmt.setString(4, wallet.getCustomerDetails().getGender());
			pstmt.setString(5, wallet.getCustomerDetails().getCustMobileNo());
			pstmt.setString(6, wallet.getCustomerDetails().getCustAddress());
			pstmt.setString(7, wallet.getCustomerDetails().getCustEmail());
			pstmt.setString(8, wallet.getCustomerDetails().getuName());
			pstmt.setString(9, wallet.getCustomerDetails().getuPassword());
			
			n = pstmt.executeUpdate();
			
			String updateQuery1 = "Insert into customerDetails values(?,?,?,curdate())";
			PreparedStatement pstmt1 = con.prepareStatement(updateQuery1);
			
			pstmt1.setString(1, wallet.getCustomerDetails().getAadharNo());
			pstmt1.setInt(1, wallet.getCustAccNo());
			pstmt1.setFloat(3, wallet.getCustBal());
			
			n1 = pstmt1.executeUpdate();
			
			{
				if (n == 1 && n1 == 1) {
					acc = wallet;
					return true;
				} else {
					return false;
				}
			}
			
			
	}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
			return true;	
		
	}

	public float showBalance() {
		
		float custBal1 = 0;
		
		try {
			con = DBUtil.getConnection();
			String displayQuery = "select * from accountDetails WHERE aadharNo=?";
			PreparedStatement pstmt = con.prepareStatement(displayQuery);
			pstmt.setString(1, aadharNo);
			ResultSet rs6 = pstmt.executeQuery();

			while (rs6.next()) {
				System.out.println(rs6.getFloat("custBal"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return custBal1;
	}

	public boolean withdrawAmount(float amount) {
		
		try {
			con = DBUtil.getConnection();
			String withdrawQuery = "update account SET custBal = custBal-? WHERE aadharNo=?";
			PreparedStatement pstmt = con.prepareStatement(withdrawQuery);
			pstmt.setFloat(1, amount);
			pstmt.setString(2, aadharNo);
			int flag = pstmt.executeUpdate();
			if (flag == 1) {
				long tid = (int) (Math.random() * 123456 + 789654);
				LocalDateTime dt = LocalDateTime.now();
				String s = "Amount Withdrawn from Id no. =  " + Long.toString(tid) + "   on date  =  " + dt.toString();
				String transQuery = "insert into transaction values('" + aadharNo + "','" + s + "') ";
				PreparedStatement pstmt1 = con.prepareStatement(transQuery);
				pstmt1.executeUpdate();

				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	public boolean fundTransfer(int custAccNo, float amount) {
		
		int n4 = 0;
		try {
			con = DBUtil.getConnection();

			String query = "update account SET custBal = custBal-? where aadharNo=?";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setFloat(1, amount);
			pstmt.setString(2, aadharNo);
			pstmt.executeUpdate();

			String query1 = "update account SET custBal = custBal+? where custAccNo=?";
			PreparedStatement pstmt1 = con.prepareStatement(query1);
			pstmt1.setFloat(1, amount);
			pstmt1.setInt(2, custAccNo);
			pstmt1.executeUpdate();

			long tid = (int) (Math.random() * 123456 + 789654);
			LocalDateTime dt = LocalDateTime.now();
			String s = "Amount Fund Transferred from Id no. =  " + Long.toString(tid) + "   on date  =  "
					+ dt.toString();
			String transQuery = "insert into transaction values('" + aadharNo + "','" + s + "') ";
			PreparedStatement pstmt2 = con.prepareStatement(transQuery);
			pstmt2.executeUpdate();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return true;

	}
	public boolean depositAmount(float amount) {
		
		try {
			con = DBUtil.getConnection();
			String depositQuery = "Update account SET custBal = custBal + ? WHERE  aadharNo= ? ";
			PreparedStatement pstmt = con.prepareStatement(depositQuery);
			pstmt.setFloat(1, amount);
			pstmt.setString(2, aadharNo);
			int flag1 = pstmt.executeUpdate();
			if (flag1 == 1) {
				long tid = (int) (Math.random() * 123456 + 789654);
				LocalDateTime dt = LocalDateTime.now();
				String s = "Amount Deposited from Id no. =  " + Long.toString(tid) + "   on date  =  " + dt.toString();
				String transQuery = "insert into transaction values('" + aadharNo + "','" + s + "') ";
				PreparedStatement pstmt1 = con.prepareStatement(transQuery);
				pstmt1.executeUpdate();
				return true;
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return true;
	}
	
	

	public List<String> printTransaction() {
		
		try {
			con = DBUtil.getConnection();
			String trans = "select * from transaction WHERE aadharNo=?";
			PreparedStatement pstmt = con.prepareStatement(trans);
			pstmt.setString(1, aadharNo);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString(2));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		

	}


	public boolean checkUserName(String uName) {
		// TODO Auto-generated method stub
		return false;
	}
}