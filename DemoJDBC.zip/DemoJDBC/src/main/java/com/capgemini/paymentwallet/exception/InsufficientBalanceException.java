package com.capgemini.paymentwallet.exception;

public class InsufficientBalanceException extends Exception{

}
