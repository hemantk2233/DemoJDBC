package com.capgemini.paw.exception;

public class NoLoginIdFound extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
