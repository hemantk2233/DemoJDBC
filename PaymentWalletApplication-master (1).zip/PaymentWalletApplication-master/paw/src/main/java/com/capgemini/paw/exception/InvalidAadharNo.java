package com.capgemini.paw.exception;

public class InvalidAadharNo extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
