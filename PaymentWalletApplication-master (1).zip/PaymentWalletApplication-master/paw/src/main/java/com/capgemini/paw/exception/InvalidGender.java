package com.capgemini.paw.exception;

public class InvalidGender extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
