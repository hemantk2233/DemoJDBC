package com.capgemini.paw.exception;

public class InvalidphoneNo extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
