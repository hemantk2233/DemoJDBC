package com.capgemini.paw.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class PaymentAppDAOTest extends Exception {

	
	@Test
	public void testCreateAccount() {
		fail("Not yet implemented");
	}

}
